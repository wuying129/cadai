# AI电商海报生成系统

基于AI的电商海报批量生成系统，支持从产品图片和描述自动生成一套完整的电商视觉海报。

## 系统架构

```
用户输入 ──→ 设计AI ──→ 提示词解析 ──→ 批量图像生成 ──→ 前端展示
   │              │              │              │
产品图片      生成设计方案    海报名称+提示词    海报图片
产品说明    (design_output)   (prompts.json)   (*.jpg)
```

## 目录结构

```
poster-generator/
├── backend/                 # 后端API服务
│   ├── app.py              # FastAPI主应用
│   ├── core/               # 核心模块
│   │   ├── design_generator.py    # 设计AI生成器
│   │   ├── poster_generator.py    # 海报图片生成器
│   │   └── batch_processor.py     # 批量处理器
│   ├── utils/              # 工具模块
│   │   ├── logger.py       # 日志工具
│   │   └── storage.py      # 存储管理
│   └── requirements.txt    # Python依赖
├── frontend/               # 前端页面
│   └── index.html          # 主页面
├── data/                   # 数据目录
│   ├── uploads/            # 上传的图片
│   ├── outputs/            # 生成的海报
│   ├── designs/            # 设计方案输出
│   └── prompts/            # 解析的提示词
├── logs/                   # 日志目录
│   ├── api.log             # API日志
│   └── task_*.log          # 任务日志
├── start.sh                # Linux/Mac启动脚本
└── README.md               # 说明文档
```

## 快速开始

### 1. 安装依赖

```bash
cd backend
pip install -r requirements.txt
```

### 2. 启动后端服务

```bash
# Linux/Mac
chmod +x start.sh
./start.sh

# 或手动启动
cd backend
python -m uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

### 3. 打开前端页面

用浏览器打开 `frontend/index.html`

## API接口

### 健康检查
```
GET /
```

### 上传图片
```
POST /api/upload-images
Content-Type: multipart/form-data

参数:
- user_id: 用户ID
- product_id: 产品ID
- files: 图片文件列表（最多9张）
```

### 开始生成
```
POST /api/generate
Content-Type: application/json

{
    "user_id": "user_123",
    "product_id": "product_456",
    "product_description": "产品描述..."
}

返回:
{
    "success": true,
    "task_id": "abc12345",
    "message": "任务已创建"
}
```

### 查询任务状态
```
GET /api/task/{task_id}

返回:
{
    "task_id": "abc12345",
    "status": "generating",  // pending/processing/design_complete/generating/completed/failed
    "progress": 60,
    "message": "正在生成: 海报03 - 工艺展示",
    ...
}
```

### 获取海报列表
```
GET /api/posters/{user_id}/{product_id}

返回:
{
    "posters": [
        {"name": "海报01 - 主KV视觉", "filename": "poster_01.jpg", "url": "/api/poster/..."}
    ]
}
```

### 下载海报
```
GET /api/poster/{user_id}/{product_id}/{filename}
```

## 日志说明

### API日志 (logs/api.log)
记录所有API请求和系统事件：
```
2025-01-01 12:00:00 | INFO | api | 创建任务: abc12345 | 用户: user_123
2025-01-01 12:00:01 | INFO | api | 更新任务: abc12345 | 状态: processing | 进度: 10%
```

### 任务日志 (logs/task_*.log)
每个任务独立的详细日志：
```
================================================================================
任务ID: abc12345
开始时间: 2025-01-01T12:00:00
================================================================================

📝 阶段1: 调用设计AI生成提示词
   ✓ 设计输出已保存: data/designs/user_123/product_456/design_output_20250101_120000.txt
   ✓ 输出长度: 15000 字符

🔍 阶段2: 解析设计输出
   ✓ 找到 10 个海报提示词
   ✓ 提示词已保存: data/prompts/user_123/product_456/prompts_20250101_120001.json
      - 海报01 - 主KV视觉
      - 海报02 - 生活场景
      ...

🎨 阶段3: 批量生成海报图片
   [1/10] 生成: 海报01 - 主KV视觉
      ✓ 成功: ['data/outputs/user_123/product_456/海报01_主KV视觉.jpg']
   ...

================================================================================
📊 生成统计
   总数: 10
   成功: 10
   失败: 0
================================================================================

🎉 任务完成!
```

## 数据存储

### 设计方案 (data/designs/)
```
designs/
└── {user_id}/
    └── {product_id}/
        ├── design_output_20250101_120000.txt  # 带时间戳版本
        └── design_output_latest.txt            # 最新版本
```

### 提示词 (data/prompts/)
```
prompts/
└── {user_id}/
    └── {product_id}/
        ├── prompts_20250101_120000.json
        └── prompts_latest.json
```

### 生成结果 (data/outputs/)
```
outputs/
└── {user_id}/
    └── {product_id}/
        ├── 海报01_主KV视觉.jpg
        ├── 海报02_生活场景.jpg
        ├── ...
        └── summary_latest.json   # 生成摘要
```

## 处理流程

1. **用户上传** → 图片保存到 `data/uploads/{user_id}/{product_id}/`
2. **设计AI分析** → 输出保存到 `data/designs/` + 记录日志
3. **提示词解析** → JSON保存到 `data/prompts/` + 记录日志
4. **批量生成** → 图片保存到 `data/outputs/` + 每张记录日志
5. **生成摘要** → summary.json 保存到 `data/outputs/`

## 技术栈

- **后端**: FastAPI + Python 3.8+
- **前端**: Vue 3 + Tailwind CSS
- **AI**: Gemini API (设计+图像生成)

## 注意事项

1. 确保网络可以访问 AI API
2. 每个任务可能需要 3-10 分钟完成
3. 生成的图片和日志会占用磁盘空间，建议定期清理
