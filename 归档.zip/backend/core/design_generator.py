#!/usr/bin/env python3
"""
设计AI生成器 - 生成电商海报设计方案
"""

import os
import base64
import asyncio
from pathlib import Path
from typing import List
import aiohttp
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 从环境变量读取配置
BASE_URL = os.getenv("API_BASE_URL", "https://ent.zetatechs.com/v1")
API_KEY = os.getenv("API_KEY", "")
MODEL_NAME = os.getenv("DESIGN_MODEL_NAME", "gemini-3-pro-preview-thinking")

SYSTEM_PROMPT = """
# 任务说明
# 任务说明 我需要为【我的产品】生成一套完整的电商KV视觉系统提示词（示例仅作为工作方式参考，不要参考具体内容）（10张海报，9:16竖版格式）。
第一步：产品信息智能提取（如果上传了图片）
请仔细分析我上传的产品图片，自动提取以下信息： ## 自动识别项目：
品牌名称识别   - 从包装/产品上识别品牌LOGO文字   - 识别中文品牌名和英文品牌名   - 提取品牌标志的设计风格（字体、图标、配色）
产品类型判断**   - 识别产品所属类别（服装/食品/电子/美妆/家居/宠物用品等）   - 识别具体产品名称（从包装文字或产品形态判断）   - 识别产品规格（尺寸、容量、重量等）
卖点提取   - 从包装上的文案提取核心卖点关键词   - 从产品图标/认证标识提取卖点（如：有机认证、无添加、进口等）   - 从产品视觉特征推断卖点（如：颜色、材质、工艺）   - 提取数据卖点（如：百分比、含量、时长等）
配色方案分析   - 提取包装主色调（RGB/HEX色值）   - 识别辅助色和点缀色   - 分析配色风格（清新/沉稳/鲜艳/高级等）
设计风格判断   - 识别包装设计风格（极简/复古/可爱/科技/艺术等）   - 识别字体风格（衬线/无衬线/手写等）   - 识别图案元素（水彩/几何/插画/摄影）
目标受众推断   - 根据包装风格推断目标用户群体   - 根据产品类型推断年龄段   - 根据价格定位推断消费层级
产品参数提取   - 从包装文字提取产品规格（净含量/尺码/功率等）   - 提取成分信息/配料表/营养成分   - 提取使用说明/注意事项   - 提取生产日期/保质期/储存方式。
产品细节识别   
- 识别产品材质质感（光滑/粗糙/哑光/高光等）
识别产品结构特点（可拆卸/折叠/便携等）
识别包装特色（自封袋/泵头/喷雾/滴管等）
输出格式：
请将识别结果整理为以下格式：
【识别报告】
品牌名称：[中文] / [英文] 
产品类型：[大类] - [具体产品] 
产品规格：[具体规格] 
核心卖点：[卖点1 - 中英文]
[卖点2 - 中英文]
[卖点3 - 中英文]
[卖点4 - 中英文]
[卖点5 - 中英文]
主色调：[颜色名称] (#HEX) + [颜色名称] (#HEX)
辅助色：[颜色名称] (#HEX)
设计风格：[风格描述]
目标受众：[用户画像]
品牌调性：[调性描述]
包装亮点：[特殊设计元素]
第二步：视觉风格选择 
基于识别的产品信息，请推荐最适合的视觉风格（也可手动指定）：视觉风格选项
（AI自动推荐或手动选择）
□ 杂志编辑风格（高级、专业、大片感、粗衬线标题、极简留白）
□ 水彩艺术风格（温暖、柔和、晕染效果、手绘质感）
□ 科技未来风格（冷色调、几何图形、数据可视化、蓝光效果）
□ 复古胶片风格（颗粒质感、暖色调、怀旧氛围、宝丽来边框）
□ 极简北欧风格（性冷淡、大留白、几何线条、黑白灰）
□ 霓虹赛博风格（荧光色、描边发光、未来都市、暗色背景）
□ 自然有机风格（植物元素、大地色系、手工质感、环保理念）
AI推荐依据： - 根据产品类型自动匹配最佳风格 - 根据包装设计风格延续品牌调性 - 根据目标受众审美偏好推荐 --
第三步：文字排版效果选择
文字排版效果（AI自动推荐或手动选择）
□ 粗衬线大标题 + 细线装饰 + 网格对齐（杂志风）
□ 玻璃拟态卡片 + 半透明背景 + 柔和圆角（现代风）
□ 3D浮雕文字 + 金属质感 + 光影效果（奢华风）
□ 手写体标注 + 水彩笔触 + 不规则布局（艺术风）
□ 无衬线粗体 + 霓虹描边 + 发光效果（赛博风）
□ 极细线条字 + 大量留白 + 精确对齐（极简风）
第四步：生成完整提示词系统
请严格按照以下要求生成：视觉风格选择（必选其一）
□ 杂志编辑风格（高级、专业、大片感、粗衬线标题、极简留白）
□ 水彩艺术风格（温暖、柔和、晕染效果、手绘质感）
□ 科技未来风格（冷色调、几何图形、数据可视化、蓝光效果）
□ 复古胶片风格（颗粒质感、暖色调、怀旧氛围、宝丽来边框）
□ 极简北欧风格（性冷淡、大留白、几何线条、黑白灰）
□ 霓虹赛博风格（荧光色、描边发光、未来都市、暗色背景）
□ 自然有机风格（植物元素、大地色系、手工质感、环保理念） 
# 文字排版效果（必选其一） 
□ 粗衬线大标题 + 细线装饰 + 网格对齐（杂志风）
□ 玻璃拟态卡片 + 半透明背景 + 柔和圆角（现代风）
□ 3D浮雕文字 + 金属质感 + 光影效果（奢华风）
□ 手写体标注 + 水彩笔触 + 不规则布局（艺术风）
□ 无衬线粗体 + 霓虹描边 + 发光效果（赛博风）
□ 极细线条字 + 大量留白 + 精确对齐（极简风）
特殊需求（可选）
【是否需要模特】：是 / 否（如果是，描述模特类型）
【是否需要场景】：是 / 否（如果是，描述场景类型）
【是否需要数据可视化】：是 / 否【其他特殊要求】：[如：必须包含产品实物、需要对比图、需要用户评价等] --- 
# 生成要求 请严格按照以下结构输出完整提示词系统：
输出结构：
LOGO生成提示词（中英双语，基于识别的品牌设计风格）
海报01 - 主KV视觉（Hero Shot，必须严格还原上传的产品图）
海报02 - 生活场景/使用场景（Lifestyle，展示产品实际使用）
海报03 - 工艺/技术/概念可视化（Process/Concept，基于识别的卖点）
海报04 - 细节特写01（Detail 01，放大产品细节）
海报05 - 细节特写02（Detail 02，材质/质感特写）
海报06 - 细节特写03（Detail 03，功能细节）
海报07 - 细节特写04 或 用户评价（Detail 04 / Review）
海报08 - 品牌故事/配色灵感（Brand Story / Moodboard，使用识别的配色）
海报09 - 产品参数/规格表（Specifications，使用识别的参数）
海报10 - 使用指南/注意事项（Usage Guide，基于产品类型）
 核心要求（重中之重）：
1. 产品图还原要求
必须在提示词中明确说明：  "严格还原上传的产品图，包括包装设计、颜色、LOGO位置、文字内容、图案元素等所有细节" - "产品外观必须与参考图完全一致，不得改变包装设计、配色方案或品牌元素" 
- "保持产品的真实材质质感（哑光/高光/磨砂/金属等）" - 例如："使用上传的朗诺RANOVA冻干鸡肉产品包装，保持蓝色袋身、水彩猫咪插画、金色LOGO等所有设计元素完全一致"
2. 文案排版要求（中英文双语）
每张海报的所有文字内容都必须采用中英文双语排版： 标题排版格式（3种可选）：
格式A - 中英堆叠（最常用）： 纯肉冻干 PURE FREEZE-DRIED  中文在上（较大字号），英文在下（较小字号），垂直堆叠，居中对齐
格式B - 中英并列： 纯肉冻干 | PURE FREEZE-DRIED  中英文横向并列，用竖线或斜杠分隔，字号相同或中文略大
格式C - 中英分离： 纯肉冻干        
[左上角] PURE FREEZE-DRIED  [右下角]  中英文分别放置在不同位置，形成视觉对比
卖点/说明文字排版格式：  100%纯肉 / 100% Pure Meat  冻干锁鲜 / Freeze-Dried Fresh  无谷配方 / Grain-Free Formula - 使用图标或符号引导 - 中文在前，英文在后，用斜杠"/"分隔 - 或采用上下堆叠，中文在上，英文在下（字号略小）
段落文字排版格式： 在慵懒的午后，给爱宠一份天然美味。 On a lazy afternoon, give your pet natural deliciousness. RANOVA冻干零食，用真材实料定义健康零食新标准。 RANOVA freeze-dried snacks redefine healthy treats with real ingredients. - 中文段落和英文段落分别成段 - 英文段落字号略小（约为中文的80-90%） - 保持行距舒适（1.5-2.0倍行高）
按钮/CTA文字格式： 立即选购 SHOP NOW → 了解更多 LEARN MORE → - 中英文并列或上下排列 - 箭头符号统一使用 →
参数表格式： | 营养成分 Nutrients | 含量 Content | | 粗蛋白 Crude Protein | ≥42% | - 表头必须中英双语 - 每个参数项都要中英文标注
3. 每张海报必须包含的元素： 中文提示词（完整详细，600-1000字） 英文Prompt（完整翻译，与中文对应） 负面词（Negative Prompts，20-30个关键词） 详细排版布局说明，包括：  - 所有文字的具体位置（左上/右下/居中等）  - 所有文字的字号大小关系（超大/大/中/小）  - 所有文字的颜色（具体色值或描述）  - 所有文字的字体风格（粗衬线/细无衬线/手写体等）  - 所有文字的中英文排版格式（堆叠/并列/分离） LOGO位置（通常左上角，统一位置） CTA按钮设计（位置、文字、样式）
4. 风格统一原则：
所有海报必须使用相同的文字排版效果 - 所有海报必须使用相同的配色系统（从产品图提取） - 所有海报必须保持品牌调性一致 - LOGO在每张海报中位置统一（左上角） - 中英文排版格式在所有海报中保持一致（选定一种格式后，10张海报都使用）
"""


class DesignGenerator:
    """设计AI生成器"""
    
    def __init__(self, api_key: str = API_KEY, base_url: str = BASE_URL):
        self.api_key = api_key
        self.base_url = base_url
        self.model_name = MODEL_NAME
    
    def _encode_image(self, path: str) -> str:
        with open(path, "rb") as f:
            return base64.standard_b64encode(f.read()).decode("utf-8")
    
    def _get_media_type(self, path: str) -> str:
        ext = Path(path).suffix.lower()
        types = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}
        return types.get(ext, "image/jpeg")
    
    async def generate(self, text_input: str, image_paths: List[str] = None) -> dict:
        """生成设计方案"""
        print("\n🎨 设计AI生成器启动")
        
        content = [{"type": "text", "text": f"{SYSTEM_PROMPT}\n\n# 用户需求\n{text_input}"}]
        
        if image_paths:
            for path in image_paths:
                if os.path.exists(path):
                    try:
                        content.append({
                            "type": "image_url",
                            "image_url": {"url": f"data:{self._get_media_type(path)};base64,{self._encode_image(path)}"}
                        })
                        print(f"  ✓ 加载图片: {path}")
                    except Exception as e:
                        print(f"  ✗ 加载失败: {path} - {e}")
        
        result = {"success": False, "raw_response": None, "reasoning": None, "usage": None, "error": None}
        
        try:
            print("  ⏳ 正在生成设计方案...")
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.base_url}/chat/completions",
                    headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
                    json={"model": self.model_name, "messages": [{"role": "user", "content": content}], "max_tokens": 16000},
                    timeout=aiohttp.ClientTimeout(total=600)
                ) as response:
                    if response.status != 200:
                        raise Exception(f"API错误 ({response.status})")
                    data = await response.json()
            
            choice = data.get("choices", [{}])[0]
            message = choice.get("message", {})
            result["raw_response"] = message.get("content", "")
            result["reasoning"] = message.get("reasoning_content", "")
            result["usage"] = data.get("usage", {})
            result["success"] = True
            print(f"  ✅ 生成成功，长度: {len(result['raw_response'])} 字符")
            
        except asyncio.TimeoutError:
            result["error"] = "请求超时"
            print(f"  ❌ {result['error']}")
        except Exception as e:
            result["error"] = str(e)
            print(f"  ❌ 错误: {result['error']}")
        
        return result
